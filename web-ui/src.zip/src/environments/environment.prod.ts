export const environment = {
  production: true,
  name: 'deploy'
};
