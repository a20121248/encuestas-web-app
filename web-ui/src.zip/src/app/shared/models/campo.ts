export class Campo {
  name: string;
  label: string;
  type: string;
  width: number;
  value: any;
  items: any;
  maxLength: number;
  messages: string[];
} 