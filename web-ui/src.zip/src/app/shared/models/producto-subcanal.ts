import { Subcanal } from './subcanal';

export class ProductoSubcanal {
  codigo: string;
  nombre: string;
  lstSubcanales: Subcanal[];
}
