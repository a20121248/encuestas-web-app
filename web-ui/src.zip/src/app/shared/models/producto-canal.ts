import { Canal } from './canal';

export class ProductoCanal {
  codigo: string;
  nombre: string;
  lstCanales: Canal[];
}
