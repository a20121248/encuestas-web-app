export class Tipo {
  id: number;
  nombre: string;
  agrupador: string;

  constructor(id: number, nombre: string, agrupador: string) {
    this.id = id;
    this.nombre = nombre;
    this.agrupador = agrupador;
  }
}
