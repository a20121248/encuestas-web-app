export class Canal {
    id: number;
    codigo: string;
    nombre: string;
    fechaCreacion: Date;
    porcentaje:number;
}