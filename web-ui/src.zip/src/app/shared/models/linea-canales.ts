export class LineaCanales {
  id: number;
  codigo: string;
  nombre: string;
  nivel: number;
  grupoId: number;
  tipoId: number;
  empresaId: number;
  fechaCreacion: Date;
  porcentaje: number;
  procesoId: number;
}
