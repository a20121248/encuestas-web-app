export class Producto {
    id: number;
    codigo: string;
    nombre: string;
    fechaCreacion: Date;
    porcentaje: number;
}