import { Linea } from './linea';
import { Canal } from './canal';

export class LineaCanal {
    linea: Linea;
    lstCanales: Canal[];
}
