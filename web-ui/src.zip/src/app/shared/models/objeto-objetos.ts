import { Objeto } from './objeto';

export class ObjetoObjetos {
  objeto: Objeto;
  lstObjetos: Objeto[];
  nombre: string;
  objetoPadre: Objeto;
  fechaCreacion: Date;
  fechaActualizacion: Date;
}
