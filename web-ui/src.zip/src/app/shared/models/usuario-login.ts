export class UsuarioLogin{
    usuarioRed: string;
    contrasenha: string;
    dominioId:number;
}