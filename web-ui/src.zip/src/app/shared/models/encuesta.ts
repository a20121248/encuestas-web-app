import { Empresa } from './empresa';
import { Justificacion } from './justificacion';

export class Encuesta {
  lstItems: object[];
  justificacion: Justificacion;
  observaciones: string;
}
