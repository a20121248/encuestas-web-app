export class Justificacion {
  id: number;
  nombre: string;
  detalle: string;
  fechaCreacion: Date;
  fechaActualizacion: Date;
  fechaEliminacion: Date;
}
