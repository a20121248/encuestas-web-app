export class Subcanal {
    codigo: string;
    nombre: string;
    porcentaje: number;
}