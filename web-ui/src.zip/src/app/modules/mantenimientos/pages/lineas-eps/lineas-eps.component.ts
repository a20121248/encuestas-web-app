import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lineas-eps',
  templateUrl: './lineas-eps.component.html',
  styleUrls: ['./lineas-eps.component.scss']
})
export class LineasEpsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
