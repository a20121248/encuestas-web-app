import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-posicion-datos',
  templateUrl: './posicion-datos.component.html',
  styleUrls: ['./posicion-datos.component.scss']
})
export class PosicionDatosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
