import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-justificaciones',
  templateUrl: './justificaciones.component.html',
  styleUrls: ['./justificaciones.component.scss']
})
export class JustificacionesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
