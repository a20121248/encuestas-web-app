import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grafico-linea',
  templateUrl: './grafico-linea.component.html',
  styleUrls: ['./grafico-linea.component.scss']
})
export class GraficoLineaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
