import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grafico-centro',
  templateUrl: './grafico-centro.component.html',
  styleUrls: ['./grafico-centro.component.scss']
})
export class GraficoCentroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
